<div class="footer">
  <p>&copy; 2020 @if(date("Y") > '2020') {{date("Y")}} @endif love yourself</p>

  <!-- to do right -->
  <div class="float-right d-none d-sm-inline">
    Naimah Daulay
  </div>
  <!-- end to do right -->
</div>