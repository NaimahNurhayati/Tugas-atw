<?php

namespace App\Models;

class promo extends Model
{
  protected $table = 'promo';
}
